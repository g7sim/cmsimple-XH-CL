<?php

$plugin_cf['filebrowser']['extensions_images']="gif, jpg, jpeg, png, svg";
$plugin_cf['filebrowser']['extensions_downloads']="doc, odt, pdf, rar, txt, zip";
$plugin_cf['filebrowser']['extensions_userfiles']="doc, flv, gif, jpg, jpeg, mp3, mp4, odt, pdf, png, rar, txt, svg, swf, webm, zip, ogg, ogv";
$plugin_cf['filebrowser']['extensions_media']="flv, mp3, mp4, swf, webm, ogg, ogv";
