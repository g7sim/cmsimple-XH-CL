<?php

$plugin_cf['toxic']['classes_available']="";

?>
