<?php

$plugin_tx['toxic']['caption_info']="Info";
$plugin_tx['toxic']['label_category']="Category";
$plugin_tx['toxic']['label_class']="Class";
$plugin_tx['toxic']['label_none']="&ndash; NONE &ndash;";
$plugin_tx['toxic']['label_save']="Save";
$plugin_tx['toxic']['label_tab']="Toxic";
$plugin_tx['toxic']['alt_logo']="Ionizing radiation sign";
$plugin_tx['toxic']['cf_classes_available']="A comma separated list of class names to select from. Leave empty to allow arbitrary classes.";

?>
