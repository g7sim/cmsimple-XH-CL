<?php

const CMSIMPLE_XH_VERSION = "1.7.4";

const XH_URICHAR_SEPARATOR = "|";

const CMSIMPLE_URL = "https://example.com/";

const CMSIMPLE_ROOT = "/";
