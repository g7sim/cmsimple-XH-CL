<?php

require_once './vendor/autoload.php';

require_once './classes/JSONProcessor.php';
require_once './classes/Model.php';

require_once '../../cmsimple/classes/PageDataRouter.php';
require_once '../../cmsimple/functions.php';
