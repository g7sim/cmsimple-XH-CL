<?php

$plugin_cf['tinymce4']['init']="flexible";
$plugin_cf['tinymce4']['utf8_marker']="äöü";
$plugin_cf['tinymce4']['CDN_alt_src']="";
$plugin_cf['tinymce4']['CDN']="";
