<?php
$plugin_cf['tinymce4']['init']="full";
$plugin_cf['tinymce4']['utf8_marker']="äöü";
$plugin_cf['tinymce4']['CDN_alt_src']="";
$plugin_cf['tinymce4']['CDN']="";   //"" = locally installed, "true" = CDN Variant 