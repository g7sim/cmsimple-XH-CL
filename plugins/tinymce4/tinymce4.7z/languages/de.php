<?php
$plugin_tx['tinymce4']['cf_init']="Der Umfang der Toolbar";
$plugin_tx['tinymce4']['cf_utf-8_marker']="<p>Internal usage. <strong>Do not change!</strong></p>";
$plugin_tx['tinymce4']['cf_CDN']="CDN Version wenn ausgewählt";
$plugin_tx['tinymce4']['cf_CDN_alt_src']="alternative CDN Quelle";
$plugin_tx['tinymce4']['pageheader']="%s. Ebene Seitenkopf";
