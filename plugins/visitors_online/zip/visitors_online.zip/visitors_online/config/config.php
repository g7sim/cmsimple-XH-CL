<?php
 
$plugin_cf['visitors_online']['duration']="5";
 
?>