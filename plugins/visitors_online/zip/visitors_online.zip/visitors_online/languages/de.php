<?php
 
$plugin_tx['visitors_online']['text']="Visitors online";
 
?>