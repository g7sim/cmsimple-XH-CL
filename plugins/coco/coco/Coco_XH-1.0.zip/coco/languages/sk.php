<?php

$plugin_tx['coco']['syscheck_title']="Kontrola systému";
$plugin_tx['coco']['syscheck_phpversion']="PHP verzia ≥ %s";
$plugin_tx['coco']['syscheck_extension']="Rozšírenie '%s' načítané";
$plugin_tx['coco']['syscheck_encoding']="Kódovanie 'UTF-8' nastavené";
$plugin_tx['coco']['syscheck_magic_quotes']="Magic quotes runtime off";
$plugin_tx['coco']['syscheck_writable']="Do adresára '%s' možno zapisovať";
$plugin_tx['coco']['menu_main']="Co-Contents";
$plugin_tx['coco']['confirm_delete']="Celý obsah \"%s\" bude vymazaný!";
$plugin_tx['coco']['error_invalid_name']="Názvy v Co-content môžu obsahovať iba  a-z, 0-9 a _ !";
$plugin_tx['coco']['cf_folder_data']="Cesta k adresáru relatívna ku koreňovému adresáru CMSimple, kam sa majú ukladať dáta pluginu. Napr.: \"userfiles/coco/\". Ak nič neuvediete, budú sa dáta zapisovať do adresára pluginu /data.";

?>
