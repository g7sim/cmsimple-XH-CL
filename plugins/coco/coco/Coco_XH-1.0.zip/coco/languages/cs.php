<?php

	$plugin_tx['coco']['syscheck_title']="Kontrola systému";
	$plugin_tx['coco']['syscheck_phpversion']="PHP verze ≥ %s";
	$plugin_tx['coco']['syscheck_extension']="Rozšíření '%s' načteno";
	$plugin_tx['coco']['syscheck_encoding']="Kódování 'UTF-8' nastaveno";
	$plugin_tx['coco']['syscheck_magic_quotes']="Magic quotes runtime off";
	$plugin_tx['coco']['syscheck_writable']="Do adresáře '%s' lze zapisovat";
	$plugin_tx['coco']['menu_main']="Co-Contents";
	$plugin_tx['coco']['confirm_delete']="Veškerý obsah z \"%s\" bude smazán!";
	$plugin_tx['coco']['error_invalid_name']="Názvy v Co-content mohou obsahovat jen  a-z, 0-9 a _ !";
	$plugin_tx['coco']['cf_folder_data']="Cesta k adresáři relativní ke kořenovému adresáři CMSimple, kam se mají ukládat data pluginu. Např.: \"userfiles/coco/\". Pokud nic neuvedete, budou se data ukládat  do adresáře pluginu /data.";

?>