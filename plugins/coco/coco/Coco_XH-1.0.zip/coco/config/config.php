<?php

$plugin_cf['coco']['folder_data']="";

?>