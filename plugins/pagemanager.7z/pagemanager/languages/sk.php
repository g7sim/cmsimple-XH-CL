<?php

$plugin_tx['pagemanager']['button_cancel']="Zrušiť";
$plugin_tx['pagemanager']['button_delete']="Vymazať";
$plugin_tx['pagemanager']['button_ok']="OK";
$plugin_tx['pagemanager']['op_save']="Uložiť";
$plugin_tx['pagemanager']['cf_pagedata_attribute']="Voľba yes/no (predvolené yes) pre vlastnosti pagedata pre checkboxy, napr.: published alebo linked_to_menu.Upozornenie:Ak zvolíte nesprávnu vlastnosť, poškodíte pagedata.php!";
$plugin_tx['pagemanager']['cf_toolbar_show']="Ukázať nástrojovú lištu? YES alebo NO";
$plugin_tx['pagemanager']['cf_treeview_animation']="Trvanie open/close animácie v ms. 0znamená bez animácie.";
$plugin_tx['pagemanager']['cf_treeview_theme']="Téma stromového modulu: cmsimpleĎalšie témy sú na stiahnutie na: http://3-magi.net/?CMSimple_XH/Pagemanager_XH.";
$plugin_tx['pagemanager']['cf_verbose']="Ukázať informačné a potvrdzovacie dialógy? YES alebo NOYES veľmi doporučené, ak nie ste dostatočne skúsený aa dobre poznáte Pagemanager_XH.";
$plugin_tx['pagemanager']['error_nesting']="Príliš hlboko vnorené v úrovniach stránky!";
$plugin_tx['pagemanager']['error_offending_extension']="Bol zistený iný doplnok, ktorý používa vlastnú knižnicu (prečítajte v manuáli \"obmedzenia\".";
$plugin_tx['pagemanager']['error_structure_confirmation']="Viem presne, čo chcem urobiť! Chcem pokračovať.";
$plugin_tx['pagemanager']['error_structure_warning']="Našla sa chybná štruktúra stránok.Detailné vysvetlenie je v help.htm. Spojte sa so správcom stránky! Ak budete poračovať, Pagemanager štruktúru upraví, čo nemusí byť za istých okolností vo Vašom záujme.";
$plugin_tx['pagemanager']['menu_main']="Správa stránok";
$plugin_tx['pagemanager']['message_confirm_deletion']="Stránka bude vymazaná so všetkými svojimi podstránkami!";
$plugin_tx['pagemanager']['message_confirm_leave']="*** ÚPRAVY NEBOLI ULOŽENÉ! ***\r\n\r\nPotvrďte ich uloženie, inak sa vykonané zmeny stratia!\r\n";
$plugin_tx['pagemanager']['message_save_failure']="Štruktúru stránky sa nepodarilo uložiť do \"%s\".";
$plugin_tx['pagemanager']['message_save_success']="Štruktúra stránky bola úspešne uložená.";
$plugin_tx['pagemanager']['message_warning_leave']="Vaše zmeny sa neuložia!";
$plugin_tx['pagemanager']['op_copy']="Kopírovať";
$plugin_tx['pagemanager']['op_cut']="Vystrihnúť";
$plugin_tx['pagemanager']['op_remove']="Vymazať";
$plugin_tx['pagemanager']['op_paste']="Vložiť";
$plugin_tx['pagemanager']['op_rename']="Premenovať";
$plugin_tx['pagemanager']['syscheck_extension']="Rozšírenie '%s' načítané";
$plugin_tx['pagemanager']['syscheck_jquery']="jQuery4CMSimple Plugin nainštalovaný.";
$plugin_tx['pagemanager']['syscheck_phpversion']="PHP-verzia ≥ %s";
$plugin_tx['pagemanager']['syscheck_title']="Systémová kontrola";
$plugin_tx['pagemanager']['syscheck_writable']="'%s' umožňuje zápis";
$plugin_tx['pagemanager']['syscheck_xhversion']="CMSimple_XH-Verzia ≥ %s";
$plugin_tx['pagemanager']['treeview_loading']="Načítavam...";
$plugin_tx['pagemanager']['treeview_new']="Nová stránka";

?>
