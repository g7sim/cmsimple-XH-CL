﻿/*
Copyright (c) 2003-2015, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.html or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang( 'scayt', 'pt-br', {
	btn_about: 'Sobre a correção ortográfica durante a digitação',
	btn_dictionaries: 'Dicionários',
	btn_disable: 'Desabilitar correção ortográfica durante a digitação',
	btn_enable: 'Habilitar correção ortográfica durante a digitação',
	btn_langs:'Idiomas',
	btn_options: 'Opções',
	text_title: 'Correção ortográfica durante a digitação'
});