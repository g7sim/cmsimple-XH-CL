﻿/*
Copyright (c) 2003-2015, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.html or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang( 'scayt', 'et', {
	btn_about: 'SCAYT-ist lähemalt',
	btn_dictionaries: 'Sõnaraamatud',
	btn_disable: 'SCAYT keelatud',
	btn_enable: 'SCAYT lubatud',
	btn_langs:'Keeled',
	btn_options: 'Valikud',
	text_title:  'Õigekirjakontroll kirjutamise ajal'
});
