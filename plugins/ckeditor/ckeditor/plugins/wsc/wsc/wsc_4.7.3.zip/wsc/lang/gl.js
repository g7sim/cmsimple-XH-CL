﻿/*
Copyright (c) 2003-2015, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.html or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang( 'wsc', 'gl', {
	btnIgnore: 'Ignorar',
	btnIgnoreAll: 'Ignorar Todas',
	btnReplace: 'Substituir',
	btnReplaceAll: 'Substituir Todas',
	btnUndo: 'Desfacer',
	changeTo: 'Cambiar a',
	errorLoading: 'Error loading application service host: %s.',
	ieSpellDownload: 'O corrector ortográfico non está instalado. ¿Quere descargalo agora?',
	manyChanges: 'Corrección ortográfica rematada: %1 verbas substituidas',
	noChanges: 'Corrección ortográfica rematada: Non se substituiu nengunha verba',
	noMispell: 'Corrección ortográfica rematada: Non se atoparon erros',
	noSuggestions: '- Sen candidatos -',
	notAvailable: 'Sorry, but service is unavailable now.',
	notInDic: 'Non está no diccionario',
	oneChange: 'Corrección ortográfica rematada: Unha verba substituida',
	progress: 'Corrección ortográfica en progreso...',
	title: 'Spell Checker',
	toolbar: 'Corrección Ortográfica'
});
