﻿/*
Copyright (c) 2003-2015, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.html or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang( 'wsc', 'km', {
	btnIgnore: 'មិនផ្លាស់ប្តូរ',
	btnIgnoreAll: 'មិនផ្លាស់ប្តូរ ទាំងអស់',
	btnReplace: 'ជំនួស',
	btnReplaceAll: 'ជំនួសទាំងអស់',
	btnUndo: 'សារឡើងវិញ',
	changeTo: 'ផ្លាស់ប្តូរទៅ',
	errorLoading: 'Error loading application service host: %s.',
	ieSpellDownload: 'ពុំមានកម្មវិធីពិនិត្យអក្ខរាវិរុទ្ធ ។ តើចង់ទាញយកពីណា?',
	manyChanges: 'ការពិនិត្យអក្ខរាវិរុទ្ធបានចប់: %1 ពាក្យបានផ្លាស់ប្តូរ',
	noChanges: 'ការពិនិត្យអក្ខរាវិរុទ្ធបានចប់: ពុំមានផ្លាស់ប្តូរ',
	noMispell: 'ការពិនិត្យអក្ខរាវិរុទ្ធបានចប់: គ្មានកំហុស',
	noSuggestions: '- គ្មានសំណើរ -',
	notAvailable: 'Sorry, but service is unavailable now.',
	notInDic: 'គ្មានក្នុងវចនានុក្រម',
	oneChange: 'ការពិនិត្យអក្ខរាវិរុទ្ធបានចប់: ពាក្យមួយត្រូចបានផ្លាស់ប្តូរ',
	progress: 'កំពុងពិនិត្យអក្ខរាវិរុទ្ធ...',
	title: 'Spell Checker',
	toolbar: 'ពិនិត្យអក្ខរាវិរុទ្ធ'
});
